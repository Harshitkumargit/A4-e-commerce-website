# app.py
from flask import Flask
from flask import render_template , url_for , redirect , request , jsonify , session , Response
from flask_session import Session 
from flask_sqlalchemy import SQLAlchemy
from werkzeug.security import generate_password_hash,check_password_hash

app=Flask(__name__)
app.config['SECRET_KEY']='ar12@gtmnB'
app.config['SQLALCHEMY_DATABASE_URI']='sqlite:///main.db'
db=SQLAlchemy(app)

class Student(db.Model):
    id=db.Column(db.Integer,primary_key=True)
    name = db.Column(db.String(50),default='')
    student_id= db.Column(db.Integer(),unique=True,nullable=False)
    password_hash =db.Column(db.String(128),nullable=False)
    def set_password(self,password):
        self.password_hash=generate_password_hash(password)
    def check_password(self,password):
        return check_password_hash(self.password_hash,password)
    def __init__(self,student_id,name):
        self.student_id=student_id
        self.name=name

app.config['SESSION_TYPE'] = 'sqlalchemy'  # Use SQLAlchemy as the session storage backend
app.config['SESSION_SQLALCHEMY'] = db 

# Initialize the session extension
Session(app)


# AUTHENTICATION
@app.route('/authentication')
def index():
    return render_template("authentication.html")

@app.route('/signup' , methods=['POST' , 'GET'])
def signup():
    if request.method == 'POST':
        data=request.get_json()
        name=data.get("sname")
        student_id=data.get("sstud_id")
        password=data.get("spassword")
        exist_id=Student.query.filter_by(student_id=student_id).first()
        if exist_id:
            return jsonify({"success":False})
        new_student=Student(name=name,student_id=student_id)
        new_student.set_password(password)
        db.session.add(new_student)
        db.session.commit()
        return jsonify({'success':'True'})
    
@app.route('/login' , methods=['POST','GET'])
def login():
    if request.method=='POST':
        admin=False
        data=request.get_json()
        student_id=data.get("lstud_id")
        if student_id == '808132':
            admin=True
        password=data.get("lpassword")
        exist_id=Student.query.filter_by(student_id=student_id).first()
        if not exist_id:
            return jsonify({"success":False})
        elif exist_id and exist_id.check_password(password):
            session["user_id"]=exist_id.student_id
            session["username"]=exist_id.name
            if admin:
                session['role']='Admin'
                return jsonify({"success":True , "admin":1})
            else:
                session['role']='user'
                return jsonify({"success":True})
        else:
            return jsonify({"success":False})

@app.route('/logout', methods=['POST'])
def logout():
    session.clear()
    return redirect(url_for('redirection'))

@app.route('/')
def redirection():
    return redirect('/authentication')

@app.route('/home')
def home():
    return render_template('index.html')

@app.route('/products')
def products():
    return render_template('product.html')

@app.route('/about')
def about():
    return render_template('about.html')

@app.route('/contact')
def contact():
    return render_template('contact.html')

# B_A REQUESTS
@app.after_request
def add_no_cache_headers(response):
    response.headers['Cache-Control'] = 'no-store, no-cache, must-revalidate, post-check=0, pre-check=0'
    response.headers['Pragma'] = 'no-cache'
    response.headers['Expires'] = '-1'
    return response

@app.before_request
def before_specific_route():
    if request.path == '/':
        if 'user_id' in session:
            return redirect('/home')
    elif request.path == '/authentication':
        if 'user_id' in session:
            return redirect('/home')
    elif request.path == '/home':
        if 'user_id' in session:
            return render_template('index.html')
        else:
            return redirect('/authentication')
    elif request.path == '/products':
        if 'user_id' in session:
            return render_template('product.html')
        else:
            return redirect('/authentication')


with app.app_context():
    db.create_all()
    db.session.commit()

if __name__ == '__main__':
    app.run(debug=True)
