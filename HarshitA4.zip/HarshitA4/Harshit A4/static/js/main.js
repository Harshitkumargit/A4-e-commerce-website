function openPopup(title, rate, details, enquireLink) {
    document.getElementById('popup-title').innerText = title;
    document.getElementById('popup-rate').innerText = rate;
    document.getElementById('popup-details').innerText = details;
    document.getElementById('enquire-link').href = enquireLink;

    document.getElementById('popup-container').style.display = 'flex';
}

function closePopup() {
    document.getElementById('popup-container').style.display = 'none';
}